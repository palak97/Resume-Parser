import alpha1
import pandas as pd

def recommend(path_description,resume_data_path,read_type):
    # print("QQQEEEEXX")


    # print("SSSSEEEE")

    final_skills,sorted_index = getskills() #function to read all skills and their sorted index from file
    # print('8')
    #read resume data from csv file
    data = pd.read_csv(resume_data_path)
    # print('9')
    #extract skills from job decription document
    job_skills = alpha1.description_manipulation(path_description,read_type)

    # print('job skills:',job_skills)
    job_skills = alpha1.match(final_skills,sorted_index,job_skills)

    matched_skills= []
    for i in range(len(data)):
        matched_skills.append(alpha1.matchSkills(job_skills,data['skills'][i]))

    print(len(matched_skills))
    matched_perc = []
    ab = len(job_skills)
    # print('ab',ab,job_skills)
    for i in range(len(matched_skills)):
        matched_perc.append(len(matched_skills[i])/ab)
        # print(data['filename'][i],len(known_skills[i]))

    db1 = { 'filename':     data['filename'],
            'known_skills': data['skills'],
            'mathced_skills':matched_skills,
            'perc_match':   matched_perc    }

    df = pd.DataFrame(db1, columns = ['filename', 'known_skills', 'mathced_skills', 'perc_match'])
    df.to_csv('allasdf.csv')
    return df
    # list1 = alpha1.sort_list(data['filename'], known_len)[-10:]
    # print(list1[:30])
 #   return alpha1.sort_list(data['filename'], known_len)



def getskills():
    # print("EEEE")
    final_skills = alpha1.readSkills('all_skills.txt')
    final_skills=sorted(final_skills, key=lambda s: s.lower())
    # print(final_skills[:10])
    # print("EWWE")
    sorted_index = alpha1.alphabet_index_list(final_skills)
    # print('index',sorted_index)
    # print("QQE")
    return final_skills,sorted_index
# def sorting(known_skills):
#     a = sorted(known_skills, key=lambda s: len(s))
#




def resumeTocsv(resumes_dir_path):
    document_list = []
    documents = []
    for path, subdirs, files in os.walk(resumes_dir_path):
        for name in files:
            if(os.path.splitext(os.path.join(path, name))[1] == ".docx" or os.path.splitext(os.path.join(path, name))[1] == ".DOCX"):
                document_list.append(os.path.join(path, name))
                document = Document(os.path.join(path, name))
                documents.append(document)
    print('read:',len(documents))

    a = experience_count(documents)

    # print(a)
def experince_count(documents_object_list):
    documents = documents_object_list
    final_experience_list = []
    string = ''

    for i_document in range(0, len(documents)):
        paragraph = documents[i_document].paragraphs
        sample_list = []
        for i in paragraph:
            sample_list.append(i.text)
        if(len(documents[i_document].tables) > 0):
            for i_table_count in range(0, len(documents[i_document].tables)):
                table = documents[i_document].tables[i_table_count]
                for row in table.rows:
                    for cell in row.cells:
                        for paragraph in cell.paragraphs:
                            sample_list.append(paragraph.text)

        sample_list = ' '.join(sample_list)
        sample_list = sample_list.split(' ')
        sample_list = [item for item in sample_list if item != '']

        exp_list = []
        for i_list in range(0, len(sample_list)):
            if(sample_list[i_list].lower() == 'experience' or
                sample_list[i_list].lower() == 'expertise' or
                sample_list[i_list].lower() == 'experienced'):
                for i_exp in range((i_list + 1), (i_list + 5)):
                    if(i_exp < len(sample_list)):
                        #print(sample_list[i_exp])
                        if(sample_list[i_exp].lower() == 'years' or sample_list[i_exp].lower() == 'months'):
                            for i_yorm in range((i_exp + 1), (i_exp + 3)):
                                #print('years : ', sample_list[i_yorm])
                                string = ''
                                #print(string)
                                for i_digit in sample_list[i_yorm]:
                                    #print(i_digit, i_digit.isdigit())
                                    if(i_digit.isdigit()):
                                        string = string + (str)(i_digit)
                                if(not string == '' and not (int)(string) > 50):
                                    exp_list.append(string)
                            for i_yorm in range((i_exp - 2), (i_exp)):
                                #print('years : ', sample_list[i_yorm])
                                for i_digit in sample_list[i_yorm]:
                                    #print(i_digit, i_digit.isdigit())
                                    if(i_digit.isdigit()):
                                        string = string + (str)(i_digit)
                                #print(string)
                                if(not string == '' and not (int)(string) > 50):
                                    exp_list.append(string)
                for i_exp in range((i_list - 5), (i_list)):
                    if(i_exp < len(sample_list)):
                        #print(sample_list[i_exp])
                        if(sample_list[i_exp].lower() == 'years' or sample_list[i_exp].lower() == 'months'):
                            for i_yorm in range((i_exp + 1), (i_exp + 3)):
                                #print('years : ', sample_list[i_yorm])
                                for i_digit in sample_list[i_yorm]:
                                    #print(i_digit, i_digit.isdigit())
                                    if(i_digit.isdigit()):
                                        string = string + (str)(i_digit)
                                if(not string == '' and not (int)(string) > 50):
                                    exp_list.append(string)
                            for i_yorm in range((i_exp - 2), (i_exp)):
                                #print('years : ', sample_list[i_yorm])
                                for i_digit in sample_list[i_yorm]:
                                    #print(i_digit, i_digit.isdigit())
                                    if(i_digit.isdigit()):
                                        string = string + (str)(i_digit)
                                #print(string)
                                if(not string == '' and not (int)(string) > 50):
                                    exp_list.append(string)
                string = ''
        exp_list.sort(reverse=True)
        if not exp_list:
            experience = 0
        else:
            experience = exp_list[0]

        final_experience_list.append([[i_document] , [experience], exp_list, [document_list[i_document]]])
    return final_experience_list
